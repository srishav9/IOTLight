<?php
// $var="";
// if(isset($_GET['lightOn'])){
// 	$var=$_GET['lightOn'];
// }
// if(isset($_GET['lightOff'])){
// 	$var=$_GET['lightOff'];
// }
echo "hello";
?>
